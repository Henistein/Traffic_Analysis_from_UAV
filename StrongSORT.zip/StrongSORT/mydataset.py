import torch
import numpy as np
import glob
from pathlib import Path
from random import randint, normalvariate
import random
from torch.utils.data import Dataset, DataLoader

class VisdroneDataset(Dataset):
  def __init__(self, seq_path, annot_path, min_len, input_len):
    self.seq_path = seq_path
    self.annot_path = annot_path
    self.seq_names = glob.glob(seq_path + '/*')
    self.annot_names = glob.glob(annot_path + '/*')
    assert len(self.seq_names) == len(self.annot_names), \
    "Size of seq_names and annot_names is different"

    self.min_len = min_len
    self.input_len = input_len
    self.names = [Path(f).stem for f in self.seq_names]
    self.id2info = self.process_annotations()
    self.ids = list(self.id2info.keys())

  
  def process_annotations(self):
    id2info = dict()
    for seqid, name in enumerate(self.names, start=1):
      annot_path = glob.glob(self.annot_path + f'/{name}.*')
      assert len(annot_path) == 1, 'Two files with the same name'
      gts = np.loadtxt(annot_path[0], delimiter=',')
      ids = set(gts[:, 1])
      for objid in ids:
        id_ = objid + seqid * 1e5
        track = gts[gts[:, 1] == objid]
        fxywh = [[t[0], t[2], t[3], t[4], t[5]] for t in track]
        if len(fxywh) >= self.min_len:
          id2info[id_] = np.array(fxywh)

    return id2info

  def fill_or_cut(self, x, former: bool):
    """
    :param x: input
    :param former: True Represents the former when the track segment is connected
    """
    lengthX, widthX = x.shape
    if lengthX >= self.input_len:
      if former:
        x = x[-self.input_len:]
      else:
        x = x[:self.input_len]
    else:
      zeros = np.zeros((self.input_len - lengthX, widthX))
      if former:
        x = np.concatenate((zeros, x), axis=0)
      else:
        x = np.concatenate((x, zeros), axis=0)
    return x

  def transform(self, x1, x2):
    # fill or cut
    x1 = self.fill_or_cut(x1, True)
    x2 = self.fill_or_cut(x2, False)
    # min-max normalization
    min_ = np.concatenate((x1, x2), axis=0).min(axis=0)
    max_ = np.concatenate((x1, x2), axis=0).max(axis=0)
    subtractor = (max_ + min_) / 2
    divisor = (max_ - min_) / 2 + 1e-5
    x1 = (x1 - subtractor) / divisor
    x2 = (x2 - subtractor) / divisor
    # numpy to torch
    x1 = torch.tensor(x1, dtype=torch.float)
    x2 = torch.tensor(x2, dtype=torch.float)
    # unsqueeze channel=1
    x1 = x1.unsqueeze(dim=0)
    x2 = x2.unsqueeze(dim=0)
    return x1, x2
     

  def __getitem__(self, item):
    info = self.id2info[self.ids[item]]
    num_frames = info.shape[0]
    # train mode
    idx_cut = random.randint(self.min_len//3, num_frames - self.min_len//3) # random crop point
    # sample pair
    info1 = info[:idx_cut + int(random.normalvariate(-5, 3))] # Add random bias to index
    info2 = info[idx_cut + int(random.normalvariate(5, 3)):] # Add random bias to index
    # time domain perturbation
    info2_t = info2.copy()
    info2_t[:, 0] += (-1) ** random.randint(1, 2)*random.randint(30, 100)
    # spatial disturbance
    info2_s = info2.copy()
    info2_s[:, 1] += (-1) ** random.randint(1, 2)*random.randint(100, 500)
    info2_s[:, 2] += (-1) ** random.randint(1, 2)*random.randint(100, 500)
    
    return self.transform(info1, info2), \
           self.transform(info2, info1), \
           self.transform(info1, info2_t), \
           self.transform(info1, info2_s), \
           (1, 0, 0, 0)
          
  
  def __len__(self):
    return len(self.ids)

def load_loader():
  dataset = VisdroneDataset(
    seq_path='/home/henistein/playground/StrongSORT/visdrone/Train/sequences',
    annot_path='/home/henistein/playground/StrongSORT/visdrone/Train/annotations',
    min_len=30,
    input_len=30
  )
  dataloader = DataLoader(
    dataset=dataset,
    batch_size=8,
    shuffle=True,
    num_workers=1,
    drop_last=False
  )
  return dataloader

if __name__ == '__main__':
  dataset = VisdroneDataset(
    seq_path='/home/henistein/playground/StrongSORT/visdrone/Train/sequences',
    annot_path='/home/henistein/playground/StrongSORT/visdrone/Train/annotations',
    min_len=30,
    input_len=30
  )
  dataloader = DataLoader(
    dataset=dataset,
    batch_size=2,
    shuffle=True,
    num_workers=1,
    drop_last=False
  )
  print(len(dataset))
  print(len(dataloader))
  for i, (p1, p2, p3, p4, labels) in enumerate(dataloader):
    pairs1 = torch.cat((p1[0], p2[0], p3[0], p4[0]), dim=0)
    pairs2 = torch.cat((p1[1], p2[1], p3[1], p4[1]), dim=0)
    label = torch.cat(labels, dim=0)

    print(pairs1.shape)
    print(label)
    break

    
     
